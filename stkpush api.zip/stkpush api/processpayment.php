<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include 'secure_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = $_POST['phone'] ?? '';
    $amount = $_POST['amount'] ?? '';
    $account_reference = $_POST['account_reference'] ?? 'UNSPECIFIED';
    $description = $_POST['description'] ?? '';

    // Prepare payload
    $payload = json_encode([
        "phone" => $phone,
        "amount" => $amount,
        "account_reference" => $account_reference,
        "description" => $description
    ]);

    // cURL to SmartPay API
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: $apiKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    // Output result
    if ($err) {
        echo "<pre style='color:red'>Error: $err</pre>";
    } else {
        echo "<pre style='color:green'>" . htmlspecialchars($response) . "</pre>";
    }
} else {
    echo "Invalid request.";
}
