<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>SmartPay STK Push</title>
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>

  <div class="form-container">
    <h2>SmartPay STK Push</h2>
    <form id="paymentForm" action="processpayment.php" method="POST">
      
      <label>Checkout_request_id</label>
      <input type="text" name="checkout_request_id" required placeholder="ws_CO_15062025163001857727856009" />

      <button type="submit">Make Payment</button>
    </form>

    <div class="response-box" id="responseBox">
      <!-- Response will appear here -->
    </div>
  </div>

</body>
</html>
