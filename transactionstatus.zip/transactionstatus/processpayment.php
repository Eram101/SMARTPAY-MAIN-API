<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include 'secure_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $checkout_request_id = $_POST['checkout_request_id'] ?? '';

    // Prepare payload
    $payload = json_encode([
        "checkout_request_id" => $checkout_request_id,
    ]);

    // cURL to SmartPay API
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: $apiKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    // Output result
    if ($err) {
        echo "<pre style='color:red'>Error: $err</pre>";
    } else {
        echo "<pre style='color:green'>" . htmlspecialchars($response) . "</pre>";
    }
} else {
    echo "Invalid request.";
}
