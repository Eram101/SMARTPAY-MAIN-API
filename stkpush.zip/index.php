<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>SmartPay STK Push</title>
  <link rel="stylesheet" href="assets/css/style.css" />
</head>
<body>

  <div class="form-container">
    <h2>SmartPay STK Push</h2>
    <form id="paymentForm" action="processpayment.php" method="POST">
      <label>Phone Number</label>
      <input type="text" name="phone" required placeholder="2547XXXXXXXX" />

      <label>Amount (KES)</label>
      <input type="number" name="amount" required placeholder="100" />

      <label>account_reference</label>
      <input type="text" name="account_reference" placeholder="100" />

      <label>Description</label>
      <input type="text" name="description" placeholder="e.g. Payment for Order #123" />

      <button type="submit">Make Payment</button>
    </form>

    <div class="response-box" id="responseBox">
      <!-- Response will appear here -->
    </div>
  </div>

</body>
</html>
