<?php

// At the top of your PHP file, after session_start()
header('Content-Type: application/json');

// Then modify your POST handling to return JSON:
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $response = ['success' => false, 'message' => ''];
    
    try {
        // Your existing switch case code...
        
        // After each successful operation:
        $response['success'] = true;
        $response['message'] = 'Operation successful';
        
    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
    }
    
    echo json_encode($response);
    exit;
}