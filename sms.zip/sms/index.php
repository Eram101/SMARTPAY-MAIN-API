<?php
$api_key = 'dac85c2c4078a202efb3867f14de3366efd5722c6e9d33';
$url = 'https://api.smartpaypesa.com/v1/sms/';

// Phone in 254 format and your message
$phone = '254727856009';
$message = 'Hello, this is a test SMS from SmartPay!';

// Prepare JSON payload
$data = json_encode(['phone'=>$phone, 'message'=>$message]);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'X-API-Key: ' . $api_key
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

echo "HTTP Code: $httpCode\n";
echo "Response:\n";
echo json_encode(json_decode($response), JSON_PRETTY_PRINT);

curl_close($ch);
?>